﻿
public static class Constants {
    public const string PluginFolder = "Plugins";
}
